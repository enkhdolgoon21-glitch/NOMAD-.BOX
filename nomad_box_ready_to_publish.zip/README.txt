NOMAD BOX — website deployment

Quick free publishing:
1. Open https://app.netlify.com/drop in a browser.
2. Sign in or create an account (ask a parent/guardian to help if needed).
3. Upload the ZIP file, or drag the extracted folder containing index.html onto the page.
4. Netlify will provide a public website URL.

Notes:
- This is a static demo website. The sample order form does not send orders to a real admin inbox.
- Product availability, prices, and delivery must be confirmed manually.
- Do not add bank card details or sensitive personal information to the demo site.
